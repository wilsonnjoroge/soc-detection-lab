# SOC Detection Lab — Vagrant Setup
### Wazuh 4.14.5 · Suricata 8.0.3 · VMware Workstation

Fully automated reproduction of the SOC Detection Lab using Vagrant + VMware Desktop provider.
Extract this zip, follow the steps below in order, and your entire lab spins up automatically.

---

## What Gets Created

```
192.168.172.140   wazuh-siem         Wazuh Manager + Indexer + Dashboard + Suricata IDS
192.168.172.150   metasploitable3    Vulnerable Ubuntu target (vsftpd, Apache, SSH, MySQL)
192.168.172.160   windows-11         Windows 11 endpoint (Wazuh agent + Sysmon + audit policy)
192.168.172.200   kali-attacker      Attack simulation platform (Hydra, Nmap, Metasploit, SQLMap)
```

All VMs sit on a VMware host-only network (`vmnet1`, `192.168.172.0/24`) — isolated from the internet after provisioning.

---

## Step 1 — Install VMware Workstation Pro

You likely have this already. Minimum version: **VMware Workstation 16+**.
Make sure it is licensed and running before continuing.

---

## Step 2 — Install Vagrant

Download and install Vagrant for your OS:
```
https://developer.hashicorp.com/vagrant/downloads
```

Verify:
```bash
vagrant --version
# Expected: Vagrant 2.3.x or higher
```

---

## Step 3 — Install the VMware Vagrant Utility

This is a **separate installer** — a background service that lets Vagrant talk to VMware.
Without it, `vagrant up` will fail even with the plugin installed.

Download it from:
```
https://developer.hashicorp.com/vagrant/docs/providers/vmware/vagrant-vmware-utility
```

On Linux (Ubuntu/Debian):
```bash
sudo dpkg -i vagrant-vmware-utility_1.0.x_linux_amd64.deb
sudo systemctl enable --now vagrant-vmware-utility

# Verify it is running
sudo systemctl status vagrant-vmware-utility
```

On Windows: run the `.exe` installer — it installs and starts the service automatically.

---

## Step 4 — Install the Vagrant VMware Desktop Plugin

```bash
vagrant plugin install vagrant-vmware-desktop
```

The plugin will prompt for a license key. The key is **free** — get it from:
```
https://www.hashicorp.com/products/vagrant/vmware
```

Verify:
```bash
vagrant plugin list
# Expected: vagrant-vmware-desktop (x.x.x)
```

---

## Step 5 — Configure vmnet1 in VMware

The lab uses VMware's `vmnet1` host-only adapter on `192.168.172.0/24`.
Verify or set this before running `vagrant up`.

Open VMware Workstation → **Edit → Virtual Network Editor**:

| Setting | Required Value |
|---|---|
| Adapter | vmnet1 |
| Type | Host-only |
| Subnet IP | 192.168.172.0 |
| Subnet Mask | 255.255.255.0 |
| DHCP | **Disabled** |

> If vmnet1 is already on a different subnet (e.g. 192.168.136.0), you have two options:
> - Change it to 192.168.172.0 in Virtual Network Editor, **or**
> - Find and replace all `192.168.172.x` addresses in the `Vagrantfile` to match your existing subnet

---

## Step 6 — Accept Box Terms (one-time, before first vagrant up)

Some Vagrant boxes require you to accept terms on Vagrant Cloud before they download.
Run these once:

**Metasploitable3:**
```bash
vagrant box add rapid7/metasploitable3-ub1404 --provider vmware_desktop
# Accept the terms when prompted
```

**Windows 11** (only if you want the Windows VM):
```bash
vagrant box add gusztavvargadr/windows-11 --provider vmware_desktop
# Accept the terms when prompted
```

Kali Linux and Ubuntu download automatically without any prompts.

---

## Step 7 — Enable the Windows VM (optional)

The Windows 11 VM is commented out by default in the `Vagrantfile` to avoid errors
if you have not accepted the box terms yet.

Once you have completed Step 6 for Windows, open `Vagrantfile` in any text editor
and uncomment the `windows-11` block. It starts at this line:

```
# config.vm.define "windows-11" do |win|
```

Remove the `#` from every line in that block to enable it.

---

## Step 8 — Internet Access During Provisioning

The provisioner downloads the following on first run — you need internet access
during `vagrant up`:

| VM | What it downloads |
|---|---|
| wazuh-siem | Wazuh all-in-one installer (~1 GB), Suricata, Suricata community rules |
| kali-attacker | Kali tool updates, Wazuh agent package |
| metasploitable3 | Wazuh agent package, Apache / MySQL / vsftpd packages |
| windows-11 | Wazuh agent MSI, Sysmon, SwiftOnSecurity Sysmon config |

After provisioning completes, the lab runs fully offline on the host-only network.

---

## Step 9 — Spin Up the Lab

**Always bring up the Wazuh SIEM first** — agents need the manager reachable when they enroll.

```bash
# Extract and enter the directory
unzip soc-lab-vagrant.zip
cd soc-lab-vagrant

# 1. Wazuh SIEM — do this first and wait for it to fully complete (~10 minutes)
vagrant up wazuh-siem

# Watch it install live (optional, in a second terminal)
vagrant ssh wazuh-siem -- tail -f /var/log/wazuh-install.log

# 2. Vulnerable target
vagrant up metasploitable3

# 3. Attacker machine
vagrant up kali-attacker

# 4. Windows endpoint (only after completing Steps 6 and 7)
vagrant up windows-11
```

---

## Step 10 — Access the Dashboard

Once `vagrant up wazuh-siem` completes:

```
URL:       https://192.168.172.140
Username:  admin
Password:  printed at the end of provision output
           also saved on the VM at: /home/vagrant/wazuh-credentials.txt
```

Retrieve the password any time:
```bash
vagrant ssh wazuh-siem -- cat /home/vagrant/wazuh-credentials.txt
```

---

## Step 11 — Migrate Agents to OS Groups

After all agents connect they land in the `default` group. Move them to the correct
OS group so your custom FIM and log collection policies apply:

```bash
vagrant ssh wazuh-siem

# List connected agents and note their IDs
sudo /var/ossec/bin/manage_agents -l

# Assign to OS groups (replace 001/002/003 with your actual IDs)
sudo /var/ossec/bin/agent_groups -a -i 001 -g linux-agents    # kali
sudo /var/ossec/bin/agent_groups -a -i 002 -g linux-agents    # metasploitable3
sudo /var/ossec/bin/agent_groups -a -i 003 -g windows-agents  # windows-11

# Remove from default
sudo /var/ossec/bin/agent_groups -r -i 001 -g default
sudo /var/ossec/bin/agent_groups -r -i 002 -g default
sudo /var/ossec/bin/agent_groups -r -i 003 -g default

# Restart Linux agents to force config sync
sudo systemctl restart wazuh-agent   # run on each Linux VM
# Windows: Services → WazuhSvc → Restart
```

---

## Running Lab Attacks

A ready-made attack cheatsheet is provisioned on the Kali VM at `~/lab-attacks.sh`:

```bash
vagrant ssh kali-attacker
cat ~/lab-attacks.sh    # review before running
```

Attack phases and what they trigger:

| Phase | Tool | Suricata Rule | Wazuh Rule |
|---|---|---|---|
| Recon — SYN scan | nmap -sS | 9000001 | — |
| Recon — ICMP sweep | nmap -sn | 9000002 | — |
| Web scan | nikto | 9000030 | 100010 |
| SSH brute force | hydra | 9000010 | 100002 → active response |
| FTP brute force | hydra | 9000020 | — |
| RDP brute force | hydra | 9000050 | 60204 → active response |
| vsftpd backdoor | metasploit | 9000040 / 9000041 | — |
| SQL injection | sqlmap | 9000031 | 100021 |
| Command injection | curl | — | 100020 |

---

## Verification Checklist

```bash
vagrant ssh wazuh-siem

# All Wazuh services healthy
sudo systemctl status wazuh-manager wazuh-indexer wazuh-dashboard filebeat

# Suricata sniffing
sudo systemctl status suricata
sudo tail -f /var/log/suricata/fast.log

# Custom rules loaded
sudo /var/ossec/bin/wazuh-control status

# Test a rule against the engine interactively
sudo /var/ossec/bin/wazuh-logtest
# Paste this line when prompted:
# Feb 28 10:15:33 metasploitable sshd[1234]: Failed password for root from 192.168.172.200 port 50000 ssh2
# Expected output: rule 5760 fires, then 100003 on repeated attempts
```

---

## Active Response Behavior

SSH brute force (rule 100002, level 12) and RDP brute force (rule 60204, level 10)
automatically trigger `firewall-drop` on the target agent for 300 seconds.

Check if a block was applied (on metasploitable3 after running Hydra):
```bash
sudo iptables -L -n | grep DROP
```

Manually unblock a stuck IP:
```bash
sudo iptables -D INPUT -s 192.168.172.200 -j DROP
sudo iptables -D FORWARD -s 192.168.172.200 -j DROP
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `vagrant up` fails immediately | Check `vagrant plugin list` — vmware-desktop plugin must be listed |
| `vagrant up` hangs / VMware error | Verify `vagrant-vmware-utility` service is running (`systemctl status vagrant-vmware-utility`) |
| Dashboard unreachable after provision | `vagrant ssh wazuh-siem -- sudo systemctl restart wazuh-dashboard` |
| Suricata not alerting | Run `ip link show` inside wazuh-siem — if the interface is not ens37, edit `/etc/suricata/suricata.yaml` and update the interface name |
| Agent shows Never Connected | Ports 1514/1515 may be blocked — check `sudo ufw status` on wazuh-siem |
| vmnet1 subnet mismatch | Virtual Network Editor → change vmnet1 subnet to 192.168.172.0/24, or update IPs in Vagrantfile |
| Metasploitable3 box error | Run `vagrant box add rapid7/metasploitable3-ub1404 --provider vmware_desktop` and accept terms |
| Windows box license error | Run `vagrant box add gusztavvargadr/windows-11 --provider vmware_desktop` and accept terms |
| Wazuh install failed | `vagrant ssh wazuh-siem -- cat /var/log/wazuh-install.log` |
| Agent not picking up group config | Restart the agent: `sudo systemctl restart wazuh-agent` |

---

## Useful Vagrant Commands

```bash
vagrant status                                        # See state of all VMs
vagrant up                                            # Start all VMs
vagrant up wazuh-siem                                 # Start a specific VM
vagrant halt                                          # Graceful shutdown all
vagrant destroy -f                                    # Wipe everything and start fresh
vagrant provision wazuh-siem                          # Re-run provisioner on existing VM
vagrant ssh wazuh-siem                                # SSH into a VM
vagrant snapshot save wazuh-siem clean-install        # Snapshot after provisioning
vagrant snapshot restore wazuh-siem clean-install     # Restore to clean state
```

---

## Project Structure

```
soc-lab-vagrant/
├── Vagrantfile                        # VM definitions — all 4 machines
├── README.md                          # This file
├── scripts/
│   ├── provision-wazuh.sh             # Wazuh all-in-one + Suricata install
│   ├── provision-kali.sh              # Kali tools + Wazuh agent + attack cheatsheet
│   ├── provision-metasploitable.sh    # Vulnerable services + Wazuh agent
│   └── provision-windows.ps1          # Wazuh agent + Sysmon + audit policy
└── configs/
    ├── wazuh/
    │   ├── ossec.conf                 # Wazuh manager config (active response, FIM, Suricata ingestion)
    │   ├── linux-agent.conf           # linux-agents group policy (FIM + log collection)
    │   └── windows-agent.conf         # windows-agents group policy (Event Log + registry + Sysmon)
    ├── rules/
    │   └── local_rules.xml            # Custom Wazuh detection rules (100001–100061)
    └── suricata/
        ├── suricata.yaml              # Suricata config (promiscuous IDS on host-only interface)
        └── local.rules                # Custom Suricata signatures (9000001–9000061)
```

---

*SOC Detection Lab — Vagrant Edition v1.0*
*Wazuh 4.14.5 · Suricata 8.0.3 · VMware Workstation*
