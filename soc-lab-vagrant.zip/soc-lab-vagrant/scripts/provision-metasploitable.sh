#!/usr/bin/env bash
# =============================================================================
# provision-metasploitable.sh — Metasploitable3 Ubuntu target provisioner
# Runs on: metasploitable3 VM (192.168.172.150)
# =============================================================================
set -euo pipefail

WAZUH_IP="192.168.172.140"
AGENT_NAME="metasploitable3-ubuntu"
AGENT_GROUP="linux-agents"

log() { echo "[META3-PROVISION] $*"; }

# ---------------------------------------------------------------------------
# 1. System prep
# ---------------------------------------------------------------------------
log "Preparing system..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
hostnamectl set-hostname metasploitable3

apt-get install -y curl wget net-tools vsftpd apache2 \
  php php-mysql mysql-server openssh-server telnetd

# ---------------------------------------------------------------------------
# 2. Configure vulnerable services (mirrors original Metasploitable3 setup)
# ---------------------------------------------------------------------------
log "Configuring vulnerable services..."

# vsftpd — keep the 2.3.4 backdoor-style config (anonymous + writable)
cat > /etc/vsftpd.conf <<'VSFTPD'
listen=YES
anonymous_enable=YES
local_enable=YES
write_enable=YES
anon_upload_enable=YES
anon_mkdir_write_enable=YES
dirmessage_enable=YES
xferlog_enable=YES
connect_from_port_20=YES
xferlog_std_format=YES
ftpd_banner=Welcome to the lab FTP service.
chroot_local_user=NO
secure_chroot_dir=/var/run/vsftpd/empty
pam_service_name=vsftpd
VSFTPD

systemctl enable vsftpd
systemctl restart vsftpd

# Apache — enable DVWA-style app
systemctl enable apache2
systemctl start apache2

# Simple vulnerable web page for command injection testing
mkdir -p /var/www/html/dvwa/vulnerabilities/exec
cat > /var/www/html/dvwa/vulnerabilities/exec/index.php <<'PHP'
<?php
if (isset($_POST['ip'])) {
    $target = $_POST['ip'];
    $cmd = "ping -c 4 $target";
    echo "<pre>" . shell_exec($cmd) . "</pre>";
}
?>
<form method="POST">
  IP: <input name="ip" value="127.0.0.1">
  <input type="submit" name="Submit" value="Submit">
</form>
PHP

# SSH — allow root login and password auth for brute force testing
sed -i 's/#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
echo "vagrant:vagrant" | chpasswd
echo "root:toor" | chpasswd
systemctl restart ssh

# Telnet — expose it (Metasploitable3 has telnet)
systemctl enable inetd 2>/dev/null || true
systemctl start telnet.socket 2>/dev/null || true

# ---------------------------------------------------------------------------
# 3. Wazuh agent install
# ---------------------------------------------------------------------------
log "Installing Wazuh agent..."
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | gpg --dearmor \
  -o /usr/share/keyrings/wazuh.gpg

echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] \
  https://packages.wazuh.com/4.x/apt/ stable main" \
  > /etc/apt/sources.list.d/wazuh.list

apt-get update -y

WAZUH_MANAGER="${WAZUH_IP}" \
WAZUH_AGENT_GROUP="${AGENT_GROUP}" \
WAZUH_AGENT_NAME="${AGENT_NAME}" \
apt-get install -y wazuh-agent

systemctl daemon-reload
systemctl enable wazuh-agent
systemctl start wazuh-agent

sleep 5
if systemctl is-active --quiet wazuh-agent; then
  log "  ✓ Wazuh agent running"
else
  log "  ✗ Wazuh agent failed — check: journalctl -u wazuh-agent"
fi

# ---------------------------------------------------------------------------
# 4. Open firewall for lab services
# ---------------------------------------------------------------------------
log "Configuring firewall for lab services..."
ufw allow 21/tcp    # FTP
ufw allow 22/tcp    # SSH
ufw allow 23/tcp    # Telnet
ufw allow 80/tcp    # HTTP
ufw allow 3306/tcp  # MySQL
ufw --force enable  2>/dev/null || true

log "Metasploitable3 provisioning complete."
cat <<SUMMARY

=============================================================================
  SOC Lab — Metasploitable3 VM Provisioned
=============================================================================
  SSH (brute force target):  ssh vagrant@192.168.172.150  (pw: vagrant)
  FTP (vsftpd target):       ftp 192.168.172.150
  Web (DVWA-style):          http://192.168.172.150/dvwa/
  MySQL:                     192.168.172.150:3306
  Wazuh agent group:         linux-agents
=============================================================================

SUMMARY
