#!/usr/bin/env bash
# =============================================================================
# provision-wazuh.sh — Wazuh SIEM + Suricata provisioner
# Runs on: wazuh-siem VM (192.168.172.140)
# =============================================================================
set -euo pipefail

WAZUH_IP="192.168.172.140"
LAB_IFACE=""   # auto-detected below

log()  { echo "[WAZUH-PROVISION] $*"; }
die()  { echo "[WAZUH-PROVISION] ERROR: $*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# 0. Detect the host-only interface (the one with 192.168.172.x)
# ---------------------------------------------------------------------------
detect_iface() {
  for iface in ens33 ens37 eth1 enp0s8; do
    if ip addr show "$iface" 2>/dev/null | grep -q "192.168.172"; then
      echo "$iface"
      return
    fi
  done
  # fallback: pick first non-lo interface
  ip -o link show | awk -F': ' '{print $2}' | grep -v lo | head -1
}

LAB_IFACE=$(detect_iface)
log "Lab interface detected: $LAB_IFACE"

# ---------------------------------------------------------------------------
# 1. System prep
# ---------------------------------------------------------------------------
log "Updating system packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y
hostnamectl set-hostname wazuh-siem

# Required packages
apt-get install -y curl wget gnupg2 apt-transport-https lsb-release \
  software-properties-common net-tools jq

# ---------------------------------------------------------------------------
# 2. Wazuh All-in-One installation
# ---------------------------------------------------------------------------
log "Starting Wazuh all-in-one installation..."

mkdir -p /root/wazuh-install && cd /root/wazuh-install

curl -sO https://packages.wazuh.com/4.x/wazuh-install.sh
curl -sO https://packages.wazuh.com/4.x/config.yml

# Inject the lab IP into config.yml
cat > config.yml <<EOF
nodes:
  indexer:
    - name: node-1
      ip: "${WAZUH_IP}"
  server:
    - name: wazuh-1
      ip: "${WAZUH_IP}"
  dashboard:
    - name: dashboard
      ip: "${WAZUH_IP}"
EOF

log "Running Wazuh installer (this takes 5–10 minutes)..."
bash wazuh-install.sh -a 2>&1 | tee /var/log/wazuh-install.log

# Save credentials to a readable location
grep -i "password\|user\|admin" /var/log/wazuh-install.log \
  > /home/vagrant/wazuh-credentials.txt 2>/dev/null || true
chmod 600 /home/vagrant/wazuh-credentials.txt

log "Wazuh installed. Credentials saved to /home/vagrant/wazuh-credentials.txt"

# ---------------------------------------------------------------------------
# 3. Verify Wazuh services
# ---------------------------------------------------------------------------
log "Waiting for Wazuh services to stabilize..."
sleep 20

for svc in wazuh-manager wazuh-indexer wazuh-dashboard filebeat; do
  if systemctl is-active --quiet "$svc"; then
    log "  ✓ $svc is running"
  else
    log "  ✗ $svc is NOT running — check /var/log/wazuh-install.log"
  fi
done

# ---------------------------------------------------------------------------
# 4. Deploy Wazuh manager config (ossec.conf)
# ---------------------------------------------------------------------------
log "Deploying ossec.conf..."
cp /tmp/ossec.conf /var/ossec/etc/ossec.conf
chown root:wazuh /var/ossec/etc/ossec.conf
chmod 640 /var/ossec/etc/ossec.conf

# ---------------------------------------------------------------------------
# 5. Deploy custom detection rules
# ---------------------------------------------------------------------------
log "Deploying local_rules.xml..."
cp /tmp/local_rules.xml /var/ossec/etc/rules/local_rules.xml
chown root:wazuh /var/ossec/etc/rules/local_rules.xml
chmod 640 /var/ossec/etc/rules/local_rules.xml

# ---------------------------------------------------------------------------
# 6. Create agent groups and deploy group configs
# ---------------------------------------------------------------------------
log "Creating agent groups..."

/var/ossec/bin/agent_groups -a -g linux-agents   2>/dev/null || true
/var/ossec/bin/agent_groups -a -g windows-agents 2>/dev/null || true

mkdir -p /var/ossec/etc/shared/linux-agents
mkdir -p /var/ossec/etc/shared/windows-agents

cp /tmp/linux-agent.conf  /var/ossec/etc/shared/linux-agents/agent.conf
cp /tmp/windows-agent.conf /var/ossec/etc/shared/windows-agents/agent.conf

chown -R root:wazuh /var/ossec/etc/shared/linux-agents
chown -R root:wazuh /var/ossec/etc/shared/windows-agents
chmod 660 /var/ossec/etc/shared/linux-agents/agent.conf
chmod 660 /var/ossec/etc/shared/windows-agents/agent.conf

# ---------------------------------------------------------------------------
# 7. Suricata installation
# ---------------------------------------------------------------------------
log "Installing Suricata..."
add-apt-repository -y ppa:oisf/suricata-stable 2>/dev/null || true
apt-get update -y
apt-get install -y suricata

# Update rules
suricata-update 2>&1 | tail -5

# ---------------------------------------------------------------------------
# 8. Deploy Suricata config
# ---------------------------------------------------------------------------
log "Deploying suricata.yaml..."
cp /tmp/suricata.yaml /etc/suricata/suricata.yaml

# Patch the interface name in suricata.yaml to match what was detected
sed -i "s/interface: ens37/interface: ${LAB_IFACE}/" /etc/suricata/suricata.yaml

# Deploy local rules
mkdir -p /etc/suricata/rules
cp /tmp/local.rules /etc/suricata/rules/local.rules

# Ensure log dir exists with correct permissions
mkdir -p /var/log/suricata
chown root:root /var/log/suricata
chmod 755 /var/log/suricata

# Create empty threshold.conf if not present
touch /etc/suricata/threshold.conf

# ---------------------------------------------------------------------------
# 9. Enable promiscuous mode and start Suricata
# ---------------------------------------------------------------------------
log "Enabling promiscuous mode on $LAB_IFACE..."
ip link set "$LAB_IFACE" promisc on

# Persist promiscuous mode across reboots
cat > /etc/systemd/system/promisc-mode.service <<EOF
[Unit]
Description=Enable promiscuous mode on ${LAB_IFACE}
After=network.target

[Service]
Type=oneshot
ExecStart=/sbin/ip link set ${LAB_IFACE} promisc on
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable promisc-mode.service

# Validate Suricata config before starting
log "Validating Suricata config..."
suricata -T -c /etc/suricata/suricata.yaml -i "$LAB_IFACE" && log "Suricata config: OK" || \
  log "WARNING: Suricata config validation failed — check /etc/suricata/suricata.yaml"

systemctl enable suricata
systemctl restart suricata

sleep 5
if systemctl is-active --quiet suricata; then
  log "  ✓ Suricata is running"
else
  log "  ✗ Suricata failed to start — check: journalctl -u suricata"
fi

# ---------------------------------------------------------------------------
# 10. Integrate Suricata → Wazuh (ossec.conf already has the localfile block)
# ---------------------------------------------------------------------------
# Ensure eve.json is readable by Wazuh
chmod 644 /var/log/suricata/eve.json 2>/dev/null || true

# ---------------------------------------------------------------------------
# 11. Restart Wazuh manager to pick up all config changes
# ---------------------------------------------------------------------------
log "Restarting Wazuh manager to apply all configs..."
systemctl restart wazuh-manager
sleep 10

# Verify rules loaded
log "Verifying custom rules loaded..."
/var/ossec/bin/wazuh-control status 2>&1 | grep -E "running|stopped" || true

# ---------------------------------------------------------------------------
# 12. Print summary
# ---------------------------------------------------------------------------
cat <<SUMMARY

=============================================================================
  SOC Lab — Wazuh SIEM VM Provisioned
=============================================================================
  Wazuh Dashboard:    https://${WAZUH_IP}
  Credentials file:   /home/vagrant/wazuh-credentials.txt
  Manager port:       1514/tcp (agent communication)
  Auth port:          1515/tcp (agent enrollment)
  Suricata interface: ${LAB_IFACE} (promiscuous mode ON)
  Suricata alerts:    /var/log/suricata/eve.json
  Suricata fast log:  /var/log/suricata/fast.log
  Custom rules:       /var/ossec/etc/rules/local_rules.xml
  Suricata rules:     /etc/suricata/rules/local.rules

  Next steps:
  1. Run 'vagrant up kali-attacker' and 'vagrant up metasploitable3'
  2. SSH into each Linux VM and enroll the Wazuh agent
  3. For Windows: uncomment the windows-11 block in Vagrantfile
  4. Verify all agents in Dashboard → Agents

  Agent enrollment command (run on each Linux target):
    sudo WAZUH_MANAGER='${WAZUH_IP}' \\
         WAZUH_AGENT_GROUP='linux-agents' \\
         WAZUH_AGENT_NAME='<agent-name>' \\
         dpkg -i ./wazuh-agent_4.14.5-1_amd64.deb
=============================================================================

SUMMARY

log "Provisioning complete."
