# =============================================================================
# provision-windows.ps1 — Windows 11 endpoint provisioner
# Runs on: windows-11 VM (192.168.172.160)
# =============================================================================

$ErrorActionPreference = "Stop"
$WAZUH_IP   = "192.168.172.140"
$WAZUH_VER  = "4.14.5"
$TEMP       = "C:\Temp"

function Log { param($msg); Write-Host "[WIN-PROVISION] $msg" }

New-Item -ItemType Directory -Force -Path $TEMP | Out-Null

# ---------------------------------------------------------------------------
# 1. Install Wazuh Agent
# ---------------------------------------------------------------------------
Log "Downloading Wazuh agent $WAZUH_VER..."
$msiUrl  = "https://packages.wazuh.com/4.x/windows/wazuh-agent-${WAZUH_VER}-1.msi"
$msiPath = "$TEMP\wazuh-agent.msi"

Invoke-WebRequest -Uri $msiUrl -OutFile $msiPath -UseBasicParsing

Log "Installing Wazuh agent..."
Start-Process msiexec.exe -Wait -ArgumentList @(
    "/i", $msiPath,
    "/q",
    "WAZUH_MANAGER=$WAZUH_IP",
    "WAZUH_AGENT_GROUP=windows-agents",
    "WAZUH_AGENT_NAME=windows-11-agent"
)

# Deploy group config
$agentConf = "C:\Temp\windows-agent.conf"
if (Test-Path $agentConf) {
    Log "Deploying windows agent group config..."
    # The group config is pushed from the manager — this is a local reference copy
    Copy-Item $agentConf "C:\Program Files (x86)\ossec-agent\shared\windows-agent.conf" -Force
}

# Start and enable the agent service
Log "Starting Wazuh agent service..."
Start-Service -Name "WazuhSvc" -ErrorAction SilentlyContinue
Set-Service -Name "WazuhSvc" -StartupType Automatic

Start-Sleep -Seconds 5
$svc = Get-Service -Name "WazuhSvc" -ErrorAction SilentlyContinue
if ($svc -and $svc.Status -eq "Running") {
    Log "  [OK] WazuhSvc is running"
} else {
    Log "  [WARN] WazuhSvc not running — check Event Viewer"
}

# ---------------------------------------------------------------------------
# 2. Enable Windows Audit Policies (for Event ID coverage)
# ---------------------------------------------------------------------------
Log "Configuring audit policies..."

# Logon events — 4624, 4625 (success + failure)
auditpol /set /subcategory:"Logon"                  /success:enable /failure:enable
auditpol /set /subcategory:"Logoff"                 /success:enable /failure:enable

# Account management — 4720, 4732 (user/group changes)
auditpol /set /subcategory:"User Account Management" /success:enable /failure:enable
auditpol /set /subcategory:"Security Group Management" /success:enable /failure:enable

# Privilege use — 4673, 4674
auditpol /set /subcategory:"Sensitive Privilege Use"  /success:enable /failure:enable

# Process creation — 4688 (without Sysmon as fallback)
auditpol /set /subcategory:"Process Creation"         /success:enable

# Scheduled tasks — 4698
auditpol /set /subcategory:"Other Object Access Events" /success:enable /failure:enable

# Policy change
auditpol /set /subcategory:"Audit Policy Change"      /success:enable /failure:enable

Log "Audit policies configured."

# ---------------------------------------------------------------------------
# 3. Install Sysmon (SwiftOnSecurity config)
# ---------------------------------------------------------------------------
Log "Installing Sysmon..."

$sysmonZip    = "$TEMP\Sysmon.zip"
$sysmonDir    = "$TEMP\Sysmon"
$sysmonConfig = "$TEMP\sysmonconfig.xml"

try {
    Invoke-WebRequest -Uri "https://download.sysinternals.com/files/Sysmon.zip" `
        -OutFile $sysmonZip -UseBasicParsing

    Expand-Archive -Path $sysmonZip -DestinationPath $sysmonDir -Force

    Invoke-WebRequest `
        -Uri "https://raw.githubusercontent.com/SwiftOnSecurity/sysmon-config/master/sysmonconfig-export.xml" `
        -OutFile $sysmonConfig -UseBasicParsing

    & "$sysmonDir\Sysmon64.exe" -accepteula -i $sysmonConfig

    Log "  [OK] Sysmon installed with SwiftOnSecurity config"
} catch {
    Log "  [WARN] Sysmon install failed: $_"
    Log "         Install manually: https://docs.microsoft.com/sysinternals/downloads/sysmon"
}

# ---------------------------------------------------------------------------
# 4. Disable Windows Firewall for lab testing
# ---------------------------------------------------------------------------
Log "Disabling Windows Firewall (lab only)..."
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

# ---------------------------------------------------------------------------
# 5. Enable RDP for brute force testing
# ---------------------------------------------------------------------------
Log "Enabling RDP..."
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' `
    -Name "fDenyTSConnections" -Value 0
Enable-NetFirewallRule -DisplayGroup "Remote Desktop"

# ---------------------------------------------------------------------------
# 6. Summary
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "============================================================="
Write-Host "  SOC Lab — Windows 11 VM Provisioned"
Write-Host "============================================================="
Write-Host "  Wazuh agent:   WazuhSvc (auto-start)"
Write-Host "  Agent group:   windows-agents"
Write-Host "  Sysmon:        Installed (SwiftOnSecurity config)"
Write-Host "  RDP:           Enabled on port 3389"
Write-Host "  Audit policy:  4624/4625/4720/4732/4698 enabled"
Write-Host ""
Write-Host "  Verify in Dashboard:"
Write-Host "  Agents -> windows-11-agent -> should show Active"
Write-Host "============================================================="
